z="
";Jz='] ||';Vz='C ]';Dz='####';Kz=' [ $';Tz='e.sh';Cz='"[■#';Rz='= b ';Ez=']>> ';Lz='g = ';Xz='nick';Qz='fi';bz='= i ';dz='info';Oz='sh 1';Sz='B ]';Nz='then';cz='I ]';Zz='sh u';Bz=' -p ';Mz='a ]';Yz='.php';Iz='= A ';Uz='= c ';Fz='" g;';az='lang';Az='read';Gz='if [';Pz='.sh';Wz='php ';Hz=' $g ';
eval "$Az$Bz$Cz$Dz$Ez$Fz$z$Gz$Hz$Iz$Jz$Kz$Lz$Mz$z$Nz$z$Oz$Pz$z$Qz$z$Gz$Hz$Rz$Jz$Kz$Lz$Sz$z$Nz$z$Oz$Tz$z$Qz$z$Gz$Hz$Uz$Jz$Kz$Lz$Vz$z$Nz$z$Wz$Xz$Yz$z$Zz$az$Pz$z$Qz$z$Gz$Hz$bz$Jz$Kz$Lz$cz$z$Nz$z$Wz$dz$Yz$z$Zz$az$Pz$z$Qz"
if [ $g = X ]
then
echo "aqil"
fi
