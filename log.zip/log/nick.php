<?php

if (strtolower(substr(PHP_OS, 0, 3)) == "win") {
    $bersih = "cls";
} else {
    $bersih = "clear";
}

date_default_timezone_set('Asia/Jakarta');
$date = date('d~M~Y H:i:s');
$green = "\e[92m";
$red = "\e[91m";
$yellow = "\e[93m";
$blue = "\e[36m";
$cyan = "\e[0;36m";
$purple = "\e[0;35m";
$brown = "\e[0;33m";
$lightgray = "\e[0;37m";
$nick = "XerXez7 Gans";
$darkgray = "\e[1;30m";
$lightblue = "\e[1;34m";
$lightgreen = "\e[1;32m";
$lightcyan = "\e[1;36m";
$lightred = "\e[1;31m";
$lightpurple = "\e[1;35m";
$bg = "\033[41;2;32m";
$gb = "\033[0;0m";
pilih:
    system($bersih);
echo "Crrxes";
echo "$lightgray
╔═╗┬─┐╦┌─┐╔╗╔┌┬┐┌─┐
╠╣ ├┬┘║├┤$lightgreen ║║║ ││└─┐
╚  ┴└─╩└─┘╝╚╝$lightgray ┴┘└─┘XerXez777$lightgreen
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ $darkgray
Oficial 2e4h :$lightgreen
Lead :$darkgray Hanz$lightgreen
Admin:$darkgray$bg Hanz-Server-NickName-Site
       InYourXDream-InYourLIT AnonMosT-InYourKing-InYourVIKNES-InYourS3rV3r-InYourHeart-InYoyr|ATCK!!1|ONE|-InYourJacbkers-InYourS!te-InYourZein-InYourNaruto-Kun-InYourKNOCK62-InYour.Valanzha•ID-InYour./Funtastik-InYourDUKUN-InYour.Dp.Queen-InYourD34DPOOL-InYour Kidhoy-InYourXerXez777-InYour_RXO403-InYour ika :v-InYourM.R.I.S-InYourM3T30r-InYourXDream-Crusher.-InYourSticy-InYour Đamn.barbie cans-InYourExtinction $gb
oficial Bogor Blackhat : $lightgreen
Lead  :$darkgray Meses/eses cyber$lightgreen
admin :$darkgray Abdul-Eses-Vita-Erik
       $bg Abdul-Eses-Erik-Vingkes-Vita-Videla-Kidhoy-Mr.Bee $gb
Oficial Gblg Crew :$lightgreen
lead  :$darkgray Takur$lightgreen
Admin :$darkgray Takur-XerXez7-IyCtr-lecek-XDream
      $bg Takur-XerXez7-LALA-Eses-ClcLx-Ctr-Sasaki-ScKidhie-IyKidhoy $gb
Thank To friends :$bg TAKUR-LALA-ESES-CTR-EXTENTION-BIMA CYBER GHOST-25JUL-SASAKI-SCKIDHIE-SULTAN-NARUTO Mem 2E4H-DFA-BUFT-GBLGCREW-BIMO$gb
		KETIK : *clear* UNTUK KEMBALI KE HALAMAN
";

