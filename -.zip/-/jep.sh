clear
php banJ.php
read -p "[##]> " p;
if [ $p = 1 ] || [ $p = 1 ]
then
xdg-open https://i.ibb.co/xs5yM86/Screenshot-20190626-171054.png
sh jep.sh
fi
if [ $p = 2 ] || [ $p = 2 ]
then
xdg-open https://i.ibb.co/XV1B0C0/Screenshot-20190626-171516.png
sh jep.sh
fi
if [ $p = 3 ] || [ $p = 3 ]
then
xdg-open https://i.ibb.co/TM2M07R/Screenshot-20190626-172300.png
sh jep.sh
fi
if [ $p = 4 ] || [ $p = 4 ]
then
xdg-open https://i.ibb.co/KyrTSMS/Screenshot-20190625-184608.png
sh jep.sh
fi
if [ $p = 5 ] || [ $p = 5 ]
then
xdg-open https://i.ibb.co/bRKv4Gs/Screenshot-20190626-185029.png
sh jep.sh
fi
if [ $p = v ] || [ $p = v ]
then
sh 1.sh
fi
